//  NumberOperations.c 
//	evenOddNum(int)
//	max3Nums(int,int,int)
//	evenOddSeries(int);
//	evenOddRange(int,int );
//	palindrome(int)
//	isPrime(int);
//	primeSeries(int);

#include <stdio.h>

// Function to check if a number is even or odd
void evenOddNum(int num) {
    printf("%d is %s\n", num, num % 2 == 0 ? "even" : "odd");
}

// Function to find the maximum of three numbers
void max3Nums(int a, int b, int c) {
    int max = a > b ? (a > c ? a : c) : (b > c ? b : c);
    printf("The maximum number is %d\n", max);
}

// Function to print a series of even and odd numbers
void evenOddSeries(int num) {
    int i;
    printf("Even numbers: ");
    for(i = 0; i <= num; i += 2) {
        printf("%d ", i);
    }
    printf("\nOdd numbers: ");
    for(i = 1; i <= num; i += 2) {
        printf("%d ", i);
    }
    printf("\n");
}

// Function to print even and odd numbers in a range
void evenOddRange(int start, int end) {
    int i;
    printf("Even numbers: ");
    for(i = start; i <= end; i++) {
        if(i % 2 == 0) {
            printf("%d ", i);
        }
    }
    printf("\nOdd numbers: ");
    for(i = start; i <= end; i++) {
        if(i % 2 != 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

// Function to check if a number is a palindrome
void palindrome(int num) {
    int reversed = 0, original = num;
    while(num != 0) {
        reversed = reversed * 10 + num % 10;
        num /= 10;
    }
    printf("%d is %s a palindrome\n", original, original == reversed ? "" : "not");
}

// Function to check if a number is prime
void isPrime(int num) {
    int i, flag = 0;
    for(i = 2; i <= num / 2; i++) {
        if(num % i == 0) {
            flag = 1;
            break;
        }
    }
    printf("%d is %s a prime number\n", num, flag == 0 ? "" : "not");
}

// Function to print a series of prime numbers
void primeSeries(int num) {
    int i, j, flag;
    printf("Prime numbers: ");
    for(i = 2; i <= num; i++) {
        flag = 0;
        for(j = 2; j <= i / 2; j++) {
            if(i % j == 0) {
                flag = 1;
                break;
            }
        }
        if(flag == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int num, num1, num2, num3;

    printf("To check if a number is even or odd: \n");
    printf("Enter a number: ");
    scanf("%d", &num);
    evenOddNum(num);

    printf("\nTo find the maximum of three numbers: \n");
    printf("Enter three numbers: ");
    scanf("%d %d %d", &num1, &num2, &num3);
    max3Nums(num1, num2, num3);

    printf("\nTo print a series of even and odd numbers: \n");
    printf("Enter a number: ");
    scanf("%d", &num);
    evenOddSeries(num);

    printf("\nTo print even and odd numbers in a range: \n");
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);
    evenOddRange(num1, num2);

    printf("\nTo check if a number is a palindrome: \n");
    printf("Enter a number: ");
    scanf("%d", &num);
    palindrome(num);

    printf("\nTo check if a number is prime: \n");
    printf("Enter a number: ");
    scanf("%d", &num);
    isPrime(num);

    printf("\nTo print a series of prime numbers: \n");
    printf("Enter a number: ");
    scanf("%d", &num);
    primeSeries(num);

}

