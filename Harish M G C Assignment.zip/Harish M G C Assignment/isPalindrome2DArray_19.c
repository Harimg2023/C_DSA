// Program to Dynamically allocate memory for 2D array,
// And checks if the 2D array is a palindrome or not.
// DMA Concept.

#include <stdio.h>
#include <stdlib.h>

// Checking the number is palindrome or not.
int isPrime(int num) {
	if (num <= 1) return 0;
	if (num % 2 == 0 && num > 2) return 0;
	for(int i = 3; i * i <= num; i+= 2) {
		if (num % i == 0)
			return 0;
	}
	return 1;
}

int main() {
	int n, m;

	printf("Enter number of rows and columns: \n");
	scanf("%d %d", &n, &m);

	// Allocating memory for 2D array
	int** arr = (int**)malloc(n * sizeof(int*));
	for(int i = 0; i < n; i++) {
		arr[i] = (int*)malloc(m * sizeof(int));
	}

	// Taking array elements.
	printf("Enter elements of the 2D array:\n");
	for(int i = 0; i < n; i++) {
		printf("Enter values for %d row: \n", i+1);
		for(int j = 0; j < m; j++) {
			scanf("%d", &arr[i][j]);
		}
	}

	// Printing the 2D array.
	printf("Enter elements of the 2D array:\n");
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m; j++) {
			printf("%d\t", arr[i][j]);
		}
		printf("\n");
	}

	// Check if 2D array is palindrome
	int isPalindrome = 1;
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m / 2; j++) {
			if(arr[i][j] != arr[i][m-j-1]) {
				isPalindrome = 0;
				break;
			}
		}
		if(!isPalindrome) break;
	}

	// Printing the result
	if(isPalindrome) {
		printf("The 2D array is a palindrome.\n");
	} else {
		printf("The 2D array is not a palindrome.\n");
	}

	// Deallocating memory
	for(int i = 0; i < n; i++) {
		free(arr[i]);
	}
	free(arr);

}

