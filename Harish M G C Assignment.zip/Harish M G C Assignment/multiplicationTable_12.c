// Program to print multiplication table of input number using arrays.

#include <stdio.h>
#define SIZE 10

int main() {
	int num, i;
	int table[SIZE];

	printf("Enter a number: ");
	scanf("%d", &num);

	// Calculating the multiplication table
	for(i = 0; i < SIZE; i++) {
		table[i] = num * (i + 1);
	}

	// Printing the multiplication table
	printf("Multiplication table for %d:\n", num);
	for(i = 0; i < SIZE; i++) {
		printf("%d x %d = %d\n", num, i + 1, table[i]);
	}

}

