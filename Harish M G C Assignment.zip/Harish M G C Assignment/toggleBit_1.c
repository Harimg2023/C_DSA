//Toggle-bit

#include <stdio.h>

int main() {
	int num, bitPosition;
	printf("Enter a number: ");
	scanf("%d", &num);
	printf("Enter the position to toggle: ");
	scanf("%d", &bitPosition);

	int bitStatus = (num>>bitPosition) & 1;	// Check if the bit at bit_position is ON or OFF
	int toggledNum = bitStatus ? (num & ~(1 << bitPosition)) : (num | (1 << bitPosition));	//// Toggle the bit at bitPosition using a conditional operator

	printf("After toggling new  number is: %d\n", toggledNum);
}
