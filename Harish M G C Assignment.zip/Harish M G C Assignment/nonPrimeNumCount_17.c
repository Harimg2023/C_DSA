//	Program to count non-primes:
//	1. Fill the array with integers starting from 1 to n
//	2. Print the array.
//	3. Replace non-prime numbers with zero and print the array.
//	4. Print total zero count.
//	5. Count the consecutive zeroes and print the largest count.
//	6. Print the starting and ending prime numbers in which large consecutive zerous present.

#include <stdio.h>
#include <stdlib.h>

// Function to check if a number is prime
int isPrime(int num) {
	if (num <= 1) return 0;
	if (num % 2 == 0 && num > 2) return 0;
	for(int i = 3; i * i <= num; i+= 2) {
		if (num % i == 0)
			return 0;
	}
	return 1;
}

int main() {
	int n;
	// Taking user input for array size
	printf("Enter a number: ");
	scanf("%d", &n);

	int* arr = (int*)malloc(n * sizeof(int));
	int zeroCount = 0;

	// Filling the array with integers starting from 1 to n
	// Printing the original array
	printf("Original array:\n");
	for(int i = 0; i < n; i++) {
		arr[i] = i + 1;
		printf("%d ", arr[i]);
		
		// Replacing non-prime numbers with zero
		if (!isPrime(i + 1)) {	
			arr[i] = 0;
			zeroCount++;
		}
	}
	printf("\n");

	// Printing the array after replacing non-primes by zero.
	printf("\nArray after replacing non-prime numbers with zero: \n");
	for(int i = 0; i < n; i++) {
		printf("Array[%d]  :  %d\n", i, arr[i]);
	}
	printf("\n");

	// Printing the total zero count.
	printf("Total count of zeros: %d\n", zeroCount);

	// Counting the largset consecutive zeros present in array.
	int maxZeros = 0, currentZeros = 0, start = 0, end = 0;
	for(int i = 0; i < n; i++) {
		if(arr[i] == 0) {
			if(currentZeros == 0) start = i;
			currentZeros++;
		} else {
			if(currentZeros > maxZeros) {
				maxZeros = currentZeros;
				end = i;
			}
			currentZeros = 0;
		}
	}

	if(currentZeros > maxZeros) {
		maxZeros = currentZeros;
		end = n;
	}

	// Printing counts.
	printf("Largest count of consecutive zeros: %d\n", maxZeros);
	printf("Prime numbers which have large zeros present: %d - %d\n", arr[end - (maxZeros+1)], arr[end]);

	// freeing the array.
	free(arr);

}

