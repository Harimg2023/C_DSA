//Program to show varios ways of arrays and pointers without functions.

#include <stdio.h>

int main() {
	int n;

	// Take user input for the size of the array
	printf("Enter the size of the array: ");
	scanf("%d", &n);

	// Declare an array of integers and take user input to initialize it
	int array[n];
	printf("Enter %d integers to initialize the array:\n", n);
	for (int i = 0; i < n; i++) {
		printf("Enter element %d: ", i + 1);
		scanf("%d", &array[i]);
	}

	// Print the array using array indexing
	printf("Array elements using array indexing:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", array[i]);
	}
	printf("\n");

	// Print the array using pointers and pointer arithmetic
	printf("Array elements using pointers:\n");
	int *ptr = array; // Initialize pointer to the beginning of the array
	for (int i = 0; i < n; i++) {
		printf("%d ", *(ptr + i)); // Access array elements using pointers
	}
	printf("\n\n");

	// Modify array elements using pointers
	printf("Enter new values to modify the array using pointers:\n");
	for (int i = 0; i < n; i++) {
		printf("Enter new value for element %d: ", i + 1);
		scanf("%d", ptr + i); // Modify array elements using pointers
	}

	// Print the modified array using array indexing
	printf("Modified array using array indexing:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", array[i]);
	}
	printf("\n");

	// Print the modified array using pointers
	printf("Modified array using pointers:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", *(ptr + i));
	}
	printf("\n");

	return 0;
}

