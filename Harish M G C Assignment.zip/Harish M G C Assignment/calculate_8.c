// Program to perform arithmatic operations using below functions:
//	int Add(int, int)
//	int Sub(int, int)
//	int Div(int, int)
//	int Mult(int, int)
//	int Modu(int, int)
//	int Pow(int, int)
//	int GreaterCommonFactor(int, int)
//
// When you compile by "gcc calculate_8.c" command you get an error it is because
// the pow function is defined in the math library, 
// and while you’ve included the math.h header file, 
// you haven’t linked the math library during the compilation process.

// To resolve this issue, 
// you need to link the math library when you compile your program. 
// You can do this by adding "-lm" at the end of your gcc command. 
// Here’s an example: "gcc calculate_8.c -lm"


#include <stdio.h>
#include <math.h>

// Function to add two numbers
int Add(int a, int b) {
    return a + b;
}

// Function to subtract two numbers
int Sub(int a, int b) {
    return a - b;
}

// Function to divide two numbers
int Div(int a, int b) {
    return a / b;
}

// Function to multiply two numbers
int Mult(int a, int b) {
    return a * b;
}

// Function to find the modulus of two numbers
int Modu(int a, int b) {
    return a % b;
}

// Function to find the power of a number
int Pow(int a, int b) {
    return pow(a, b);
}

// Function to find the greatest common factor of two numbers
int GreaterCommonFactor(int a, int b) {
    if(b == 0)
        return a;
    else
        return GreaterCommonFactor(b, a % b);
}

int main() {
    int num1, num2;

    printf("Enter two numbers: \n");
    scanf("%d %d", &num1, &num2);

    printf("Addition: %d\n", Add(num1, num2));
    printf("Subtraction: %d\n", Sub(num1, num2));
    printf("Division: %d\n", Div(num1, num2));
    printf("Multiplication: %d\n", Mult(num1, num2));
    printf("Modulus: %d\n", Modu(num1, num2));
    printf("Power: %d\n", Pow(num1, num2));
    printf("Greatest Common Factor: %d\n", GreaterCommonFactor(num1, num2));

}

