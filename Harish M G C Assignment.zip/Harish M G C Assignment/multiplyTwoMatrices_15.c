// Program to multiply 2 matrices.

#include <stdio.h>
#define MAX_SIZE 100

int main() {
	int a[MAX_SIZE][MAX_SIZE], b[MAX_SIZE][MAX_SIZE], result[MAX_SIZE][MAX_SIZE];
	int r, c, i, j, k;

	// Taking the number of rows and columns for both the matrix's
	printf("Enter the number of rows and columns for both the matrices: \n");
	scanf("%d %d", &r, &c);

	// Taking the elements of the first matrix
	printf("Enter elements of the first matrix:\n");
	for(i = 0; i < r; i++) {
		for(j = 0; j < c; j++) {
			scanf("%d", &a[i][j]);
		}
	}

	// Taking the elements of the second matrix as input from the user
	printf("Enter elements of the second matrix:\n");
	for(i = 0; i < r; i++) {
		for(j = 0; j < c; j++) {
			scanf("%d", &b[i][j]);
		}
	}

	// Multiply the matrices
	for(i = 0; i < r; i++) {
		for(j = 0; j < c; j++) {
			result[i][j] = 0;
			for(k = 0; k < c; k++) {
				result[i][j] += a[i][k] * b[k][j];
			}
		}
	}

	// Printing the result
	printf("Result matrix:\n");
	for(i = 0; i < r; i++) {
		for(j = 0; j < c; j++) {
			printf("%d ", result[i][j]);
		}
		printf("\n");
	}

}

