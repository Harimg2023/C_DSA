// Program to mask-bit using conditional operator

#include <stdio.h>

int main() {
    int num, bitPosition;

    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Enter a bit position: ");
    scanf("%d", &bitPosition);

    // Check if the bit at bit_position is ON or OFF
    int bitStatus = (num >> bitPosition) & 1;

    // Mask the bit at bit_position using a conditional operator
    int maskedNum = bitStatus ? (num & ~(1 << bitPosition)) : num;

    printf("After masking the bit at position %d of %d, the result is %d.\n", bitPosition, num, maskedNum);

}

