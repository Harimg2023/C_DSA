// Program on string segregation.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char str[100], id[10], name[50];
    double salary;

    printf("Enter the ID, Name & Salary of the employee:\n");
    fgets(str, sizeof(str), stdin);  // read string

    // Segregate id
    char* token = strtok(str, " ");
    strcpy(id, token);

    // Segregate name
    token = strtok(NULL, " ");
    strcpy(name, token);

    // Segregate salary
    token = strtok(NULL, " ");
    salary = atof(token);

    printf("ID: %s\n", id);
    printf("Name: %s\n", name);
    printf("Salary: %.2lf\n", salary);

    return 0;
}

