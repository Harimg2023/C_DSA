// Program to demonstrate call by value & call by reference:

#include <stdio.h>

// Function to swap two numbers using call by value
void swapValue(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
}

// Function to swap two numbers using call by reference
void swapReference(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int num1, num2;

    printf("Enter two numbers: \n");
    scanf("%d %d", &num1, &num2);

    printf("Before swapValue: num1 = %d, num2 = %d\n", num1, num2);
    swapValue(num1, num2);
    printf("After swapValue: num1 = %d, num2 = %d\n", num1, num2);

    printf("Before swapReference: num1 = %d, num2 = %d\n", num1, num2);
    swapReference(&num1, &num2);
    printf("After swapReference: num1 = %d, num2 = %d\n", num1, num2);

}

