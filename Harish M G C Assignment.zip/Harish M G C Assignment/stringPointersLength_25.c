// Program to show varios ways of string and pointers using functions.
// And get string length

#include <stdio.h>
#include <string.h>

int calculateStringLength(char str[]);
int calculateStringLengthUsingPointer(char *str);

int main() {
	char str1[100], str2[100];

	// Take user input for the first string
	printf("Enter the first string: ");
	fgets(str1, sizeof(str1), stdin);
	str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

	// Take user input for the second string
	printf("Enter the second string: ");
	fgets(str2, sizeof(str2), stdin);
	str2[strcspn(str2, "\n")] = '\0'; // Remove newline character

	// Calculate and print the length of the first string using array indexing
	printf("Length of the first string using array indexing: %ld\n", strlen(str1));

	// Calculate and print the length of the second string using pointers
	printf("Length of the second string using pointers: %ld\n", strlen(str2));

	// Calculate and print the length of the first string using a function
	printf("Length of the first string using a function: %d\n", calculateStringLength(str1));

	// Calculate and print the length of the second string using a function with pointers
	printf("Length of the second string using a function with pointers: %d\n", calculateStringLengthUsingPointer(str2));

	return 0;
}

// Function to calculate string length using array indexing
int calculateStringLength(char str[]) {
	int length = 0;
	while (str[length] != '\0') {
		length++;
	}
	return length;
}

// Function to calculate string length using pointers
int calculateStringLengthUsingPointer(char *str) {
	int length = 0;
	while (*str != '\0') {
		length++;
		str++;
	}
	return length;
}

