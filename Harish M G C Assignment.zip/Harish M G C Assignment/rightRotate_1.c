// Program to right-rotate using conditional operator

#include <stdio.h>

#define INT_BITS 32

int main() {
	int num, rotation;

	//Take the number and the number of rotations as inputs from the user

	printf("Enter a number: ");
	scanf("%d", &num);
	printf("Enter the number of rotations: ");	
	scanf("%d", &rotation);

	// Normalize the number of rotations in case it's greater than the number of bits
	rotation = rotation % INT_BITS;

	// Right rotate the number using a conditional operator
	int rotated_num = rotation ? ((num >> rotation) | (num << (INT_BITS - rotation))) : num;

	printf("After right rotating %d by %d positions, the result is %d.\n", num, rotation, rotated_num);

	return 0;
}

