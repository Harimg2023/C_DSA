// Program to check if a given string is palindrome or not

#include <stdio.h>
#include <string.h>

// Function to check if a string is a palindrome or not.
int isPalindrome(const char *str) {
	int length = strlen(str);
	for (int i = 0; i < length / 2; i++) {
		if (str[i] != str[length - 1 - i]) {
			return 0; // Not a palindrome
		}
	}
	return 1; // Palindrome
}

int main() {
	char inputString[100];

	// Taking user input for the string
	printf("Enter a string: ");
	scanf("%s", inputString);

	// Printing the original string
	printf("Original string: %s\n", inputString);

	// Printing the reversed string
	printf("Reversed string: ");
	for (int i = strlen(inputString) - 1; i >= 0; i--) {
		printf("%c", inputString[i]);
	}
	printf("\n");
	
	// Checking if the string is a palindrome
	if (isPalindrome(inputString)) {
		printf("The string is a palindrome.\n");
	} else {
		printf("The string is not a palindrome.\n");
	}

}

