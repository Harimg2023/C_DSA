// Program to left-rotate using conditional operator

#include <stdio.h>
#define INT_BITS 32

int main() {
    int num, rotation;

    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Enter the number of rotations: ");
    scanf("%d", &rotation);

    // Normalize the number of rotations in case it's greater than the number of bits
    rotation = rotation % INT_BITS;

    // Left rotate the number using a conditional operator
    int rotatedNum = rotation ? ((num << rotation) | (num >> (INT_BITS - rotation))) : num;

    printf("After left rotating %d by %d positions, the result is %d.\n", num, rotation, rotatedNum);

}
