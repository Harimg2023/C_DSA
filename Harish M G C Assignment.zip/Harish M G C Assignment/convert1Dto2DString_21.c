// Program to convert 1D to 2D String.

#include <stdio.h>
#include <string.h>

int main() {
    char inputString[100];
    char twoDString[25][25]; // Assuming a 25x25 2D array.

    // Taking user input for the 1D string
    printf("Enter a string: ");
    fgets(inputString, sizeof(inputString), stdin);

    // Removing the newline character from the input string if present
    int length = strlen(inputString);
    if (inputString[length - 1] == '\n') {
        inputString[length - 1] = '\0';
    }

    // Coping the 1D string into a 2D array
    int row = 0, col = 0;
    for (int i = 0; i < length; i++) {
        if (inputString[i] != ' ') {
            twoDString[row][col] = inputString[i];
            col++;
        } else {
            twoDString[row][col] = '\0'; // Null-terminating each word
            row++;
            col = 0;
        }
    }
    twoDString[row][col] = '\0'; // Null-terminating the last word

    // Printing the original 1D string
    printf("Original string: %s\n", inputString);

    // Printing the 2D string
    printf("\n2D string:\n");
    for (int i = 0; i <= row; i++) {
        printf("%s\n", twoDString[i]);
    }

}

