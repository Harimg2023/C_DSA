// Program to toggle-nibble using conditional operator

#include <stdio.h>

int main() {
    unsigned char num;
    int nibblePosition;

    printf("Enter a number: ");		// Taking the number and the nibble position as inputs from the user
    scanf("%hhu", &num);
    printf("Enter a nibble position (0 for the lower nibble, 1 for the upper nibble): ");
    scanf("%d", &nibblePosition);

    int nibbleStatus = (num >> (nibblePosition * 4)) & 0x0F;	// Check if all bits in the nibble at nibblePosition are ON or OFF

    // Toggle the nibble at nibblePosition using a conditional operator
    unsigned char toggledNum = nibbleStatus ? (num & ~(0x0F << (nibblePosition * 4))) : (num | (0x0F << (nibblePosition * 4)));

    printf("After toggling the nibble at position %d of %d, the result is %d.\n", nibblePosition, num, toggledNum);
}
