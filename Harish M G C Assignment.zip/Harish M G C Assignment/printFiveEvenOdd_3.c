// Program to accept a number from the user, and print first 5 even numbers and odd numbers. As shown in below format.
//	Scenario #1: 
//		Enter a num: 100
//		Even: 100 102 104 106 108 
//		Odd: 101 103 105 107 109
//	Scenario #2: 
//		Enter a num: 101
//		Odd: 101 103 105 107 109
//		Even: 102 104 106 108 110

#include <stdio.h>

int main() {
    int num, i;

    // Take the number as input from the user
    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Even: ");
    for(i = num; i < num + 10; i++) {
        if(i % 2 == 0) {
            printf("%d ", i);
        }
    }

    printf("\nOdd: ");
    for(i = num; i < num + 10; i++) {
        if(i % 2 != 0) {
            printf("%d ", i);
        }
    }

    printf("\n\n");


    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Odd: ");
    for(i = num; i < num + 10; i++) {
        if(i % 2 != 0) {
            printf("%d ", i);
        }
    }

    printf("\nEven: ");
    for(i = num; i < num + 10; i++) {
        if(i % 2 == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}
