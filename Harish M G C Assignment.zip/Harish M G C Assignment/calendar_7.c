// Program to print month calender:
//	isLeap(int);
//	maxDays(int,int)
//	dayOfWeek(int,int,int)
//	printCal(int,int)

#include <stdio.h>
#define INT_BITS 32

// Function to check if a year is a leap year
int isLeap(int year) {
    return (year % 400 == 0) || (year % 100 != 0 && year % 4 == 0);
}

// Function to get the maximum number of days in a month
int maxDays(int month, int year) {
    int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    return month == 2 ? (28 + isLeap(year)) : daysInMonth[month];
}

// Function to get the day of the week
int dayOfWeek(int day, int month, int year) {
    int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
    year -= month < 3;
    return ( year + year/4 - year/100 + year/400 + t[month-1] + day) % 7;
}

// Function to print a calendar for a month
void printCal(int month, int year) {
    printf("Sun Mon Tue Wed Thu Fri Sat\n");

    int days = maxDays(month, year);
    int dow = dayOfWeek(1, month, year);

    int i;
    for(i = 0; i < dow; i++) {
        printf("    ");
    }

    for(i = 1; i <= days; i++) {
        printf("%3d ", i);
        if(++dow > 6) {
            printf("\n");
            dow = 0;
        }
    }
}

// Function to validate a date
int isValidDate(int day, int month, int year) {
    // Check the validity of year and month
    if(year < 0 || month < 1 || month > 12)
        return 0;

    // Check the validity of day
    if(day < 1 || day > maxDays(month, year))
        return 0;

    return 1;
}

int main() {
    int day, month, year;

    printf("Enter a date in dd/mm/yyyy format: ");
    scanf("%d/%d/%d", &day, &month, &year);

    // Validate the date
    if(!isValidDate(day, month, year)) {
        printf("Invalid date!\n");
        return 1;
    }

    printCal(month, year);
    printf("\n");
}

