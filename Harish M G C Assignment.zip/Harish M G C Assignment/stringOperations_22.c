// Program to perform string operations.

#include <stdio.h>
#include <string.h>

// Function prototypes
void concatenateStrings(char str1[], char str2[], char result[]);
void compareStrings(char str1[], char str2[]);
void copyString(char str[], char result[]);
void calculateStringLength(char str[]);
void reverseString(char str[]);

int main() {
	char str1[100], str2[100], result[200];
	int choice;

	while (1) {
		// Display menu for string operations
		printf("\nString Operations Menu:\n");
		printf("1. Concatenate\n");
		printf("2. Compare\n");
		printf("3. Copy\n");
		printf("4. Length\n");
		printf("5. Reverse\n");
		printf("0. Exit\n");

		// Prompt user for choice
		printf("Enter your choice (0-5): ");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				// Concatenate strings
				printf("Enter the first string: ");
				getchar(); // Consume newline character left in buffer
				fgets(str1, sizeof(str1), stdin);
				str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

				printf("Enter the second string: ");
				fgets(str2, sizeof(str2), stdin);
				str2[strcspn(str2, "\n")] = '\0'; // Remove newline character

				concatenateStrings(str1, str2, result);
				printf("Concatenated string: %s\n", result);
				break;

			case 2:
				// Compare strings
				printf("Enter the first string: ");
				getchar(); // Consume newline character left in buffer
				fgets(str1, sizeof(str1), stdin);
				str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

				printf("Enter the second string: ");
				fgets(str2, sizeof(str2), stdin);
				str2[strcspn(str2, "\n")] = '\0'; // Remove newline character

				compareStrings(str1, str2);
				break;

			case 3:
				// Copy string
				printf("Enter the string to copy: ");
				getchar(); // Consume newline character left in buffer
				fgets(str1, sizeof(str1), stdin);
				str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

				copyString(str1, result);
				printf("Copied string: %s\n", result);
				break;

			case 4:
				// Length of string
				printf("Enter the string: ");
				getchar(); // Consume newline character left in buffer
				fgets(str1, sizeof(str1), stdin);
				str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

				calculateStringLength(str1);
				break;

			case 5:
				// Reverse string
				printf("Enter the string to reverse: ");
				getchar(); // Consume newline character left in buffer
				fgets(str1, sizeof(str1), stdin);
				str1[strcspn(str1, "\n")] = '\0'; // Remove newline character

				reverseString(str1);
				break;

			case 0:
				// Exit the program
				printf("Exiting the program.\n");
				return 0;

			default:
				// Invalid choice
				printf("Invalid choice. Please enter a number between 0 and 5.\n");
		}
	}

	return 0;
}

// Function to concatenate two strings
void concatenateStrings(char str1[], char str2[], char result[]) {
	strcpy(result, str1);
	strcat(result, str2);
}

// Function to compare two strings
void compareStrings(char str1[], char str2[]) {
	if (strcmp(str1, str2) == 0) {
		printf("Strings are equal.\n");
	} else {
		printf("Strings are not equal.\n");
	}
}

// Function to copy a string
void copyString(char str[], char result[]) {
	strcpy(result, str);
}

// Function to calculate the length of a string
void calculateStringLength(char str[]) {
	printf("Length of the string: %ld\n", strlen(str));
}

// Function to reverse a string
void reverseString(char str[]) {
	printf("Reversed string: ");
	for (int i = strlen(str) - 1; i >= 0; i--) {
		printf("%c", str[i]);
	}
	printf("\n");
}

