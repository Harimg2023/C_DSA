// Program to demonstrate bit operations in functions
// bitState(num, bitPos)
// toggleBit(num, bitPos)
// toggleNibble(num, bitPos)
// leftRotate(num, bitPos)
// rightRotate(num, bitPos)
// maskBit(num, bitPos)
// printBinaryNumber(num)

#include <stdio.h>
#define INT_BITS 32

// Function to get the state of a bit
int bitState(int num, int bitPos) {
    return (num >> bitPos) & 1;
}

// Function to toggle a bit
int toggleBit(int num, int bitPos) {
    return num ^ (1 << bitPos);
}

// Function to toggle a nibble
int toggleNibble(int num, int bitPos) {
    return num ^ (0x0F << (bitPos * 4));
}

// Function to left rotate a number
int leftRotate(int num, int rotation) {
    rotation = rotation % INT_BITS;
    return rotation ? ((num << rotation) | (num >> (INT_BITS - rotation))) : num;
}

// Function to right rotate a number
int rightRotate(int num, int rotation) {
    rotation = rotation % INT_BITS;
    return rotation ? ((num >> rotation) | (num << (INT_BITS - rotation))) : num;
}

// Function to mask a bit
int maskBit(int num, int bitPos) {
    return num & ~(1 << bitPos);
}

// Function to print a number in binary
void printBinaryNumber(int num) {
    int i;
    for(i = INT_BITS - 1; i >= 0; i--) {
        printf("%d", (num >> i) & 1);
    }
    printf("\n");
}

int main() {
    int num, bitPos;

    // Take the number and the bit position as inputs from the user
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Enter a bit position: ");
    scanf("%d", &bitPos);

    printf("State of the bit at position %d: %d\n", bitPos, bitState(num, bitPos));
    printf("After toggling the bit at position %d: %d\n", bitPos, toggleBit(num, bitPos));
    printf("After toggling the nibble at position %d: %d\n", bitPos, toggleNibble(num, bitPos));
    printf("After left rotating by %d positions: %d\n", bitPos, leftRotate(num, bitPos));
    printf("After right rotating by %d positions: %d\n", bitPos, rightRotate(num, bitPos));
    printf("After masking the bit at position %d: %d\n", bitPos, maskBit(num, bitPos));
    printf("Binary representation of the number: ");
    printBinaryNumber(num);
}

