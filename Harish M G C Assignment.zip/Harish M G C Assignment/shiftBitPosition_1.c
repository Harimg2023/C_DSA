//Write a C program to shift the bit-position and check the bit is "ON" or "OFF" using conditional operator.

#include <stdio.h>

int main() {
	int num, bitPosition;
	printf("Enter a number: ");
	scanf("%d", &num);
	printf("Enter the position to shift: ");
	scanf("%d", &bitPosition);
	
	num & (1<<bitPosition) ? printf("ON") : printf("OFF");
	printf("\n");
}
