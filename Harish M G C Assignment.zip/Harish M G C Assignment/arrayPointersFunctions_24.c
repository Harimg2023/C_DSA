// Program to show various ways of arrays and pointers using functions.

#include <stdio.h>

void initializeArray(int arr[], int size);
void printArrayUsingIndex(int arr[], int size);
void printArrayUsingPointers(int arr[], int size);
void modifyArrayUsingPointers(int arr[], int size);

int main() {
	int n;

	// Take user input for the size of the array
	printf("Enter the size of the array: ");
	scanf("%d", &n);

	// Declare and initialize the array using a function
	int array[n];
	initializeArray(array, n);

	// Print the array using array indexing and a function
	printf("Array elements using array indexing:\n");
	printArrayUsingIndex(array, n);

	// Print the array using pointers and a function
	printf("Array elements using pointers:\n");
	printArrayUsingPointers(array, n);

	// Modify array elements using pointers and a function
	modifyArrayUsingPointers(array, n);

	// Print the modified array using array indexing and a function
	printf("Modified array using array indexing:\n");
	printArrayUsingIndex(array, n);

	// Print the modified array using pointers and a function
	printf("Modified array using pointers:\n");
	printArrayUsingPointers(array, n);

	return 0;
}

// Function to initialize the array with user input
void initializeArray(int arr[], int size) {
	printf("Enter %d integers to initialize the array:\n", size);
	for (int i = 0; i < size; i++) {
		printf("Enter element %d: ", i + 1);
		scanf("%d", &arr[i]);
	}
}

// Function to print the array using array indexing
void printArrayUsingIndex(int arr[], int size) {
	for (int i = 0; i < size; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}

// Function to print the array using pointers
void printArrayUsingPointers(int arr[], int size) {
	int *ptr = arr;
	for (int i = 0; i < size; i++) {
		printf("%d ", *(ptr + i));
	}
	printf("\n");
}

// Function to modify array elements using pointers
void modifyArrayUsingPointers(int arr[], int size) {
	printf("\nEnter new values to modify the array using pointers:\n");
	for (int i = 0; i < size; i++) {
		printf("Enter new value for element %d: ", i + 1);
		scanf("%d", &arr[i]);
	}
}

