//Program to print numbers from 1 to 10 stored in an array in matrix order.

#include <stdio.h>
#define MAX_SIZE 10

int main() {
	int array[MAX_SIZE] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	int rows, cols, i, j;

	printf("Enter 2*5 matrix to print all the array elements.\n");
	printf("Enter the number of rows and columns: \n");
	scanf("%d %d", &rows, &cols);

	// Checking if the number of rows and columns is valid
	if(rows * cols > MAX_SIZE) {
		printf("Invalid number of rows and columns!\n");
		return 1;
	}

	// Printing the numbers in a matrix order
	printf("Numbers in a matrix order:\n");
	for(i = 0; i < rows; i++) {
		for(j = 0; j < cols; j++) {
			printf("%d ", array[i * cols + j]);
		}
		printf("\n");
	}

}

