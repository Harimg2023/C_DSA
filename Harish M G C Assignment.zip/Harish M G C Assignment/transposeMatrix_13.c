//Program to print transpose of a matrix

#include <stdio.h>

#define MAX_SIZE 100

int main() {
	int matrix[MAX_SIZE][MAX_SIZE];
	int transpose[MAX_SIZE][MAX_SIZE];
	int rows, cols, i, j;

	printf("Enter the number of rows and columns:\n");
	scanf("%d %d", &rows, &cols);

	// Take the elements of the matrix as input from the user
	printf("Enter elements of the matrix:\n");
	for(i = 0; i < rows; i++) {
		for(j = 0; j < cols; j++) {
			scanf("%d", &matrix[i][j]);
		}
	}

	// Print the user given matrix
	printf("The given matrix:\n");
	for(i = 0; i < rows; i++) {
		for(j = 0; j < cols; j++) {
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}

	// Calculate the transpose of the matrix
	for(i = 0; i < rows; i++) {
		for(j = 0; j < cols; j++) {
			transpose[j][i] = matrix[i][j];
		}
	}

	// Print the transpose of the matrix
	printf("Transpose of the matrix:\n");
	for(i = 0; i < cols; i++) {
		for(j = 0; j < rows; j++) {
			printf("%d ", transpose[i][j]);
		}
		printf("\n");
	}

}

