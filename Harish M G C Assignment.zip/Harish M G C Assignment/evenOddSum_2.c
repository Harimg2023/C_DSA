//Print all even number between the range of 2 numbers and print the sum of all odd numbers between the same range

#include <stdio.h>

int main() {
    int start, end, i, sum = 0;

    // Take the start and end numbers as inputs from the user
    printf("Enter the start number: ");
    scanf("%d", &start);
    printf("Enter the end number: ");
    scanf("%d", &end);

    printf("Even numbers between %d and %d are: ", start, end);
    for(i = start; i <= end; i++) {
        if(i % 2 == 0) {
            printf("%d ", i);
        } else {
            sum += i;
        }
    }

    printf("\nSum of odd numbers between %d and %d is: %d\n", start, end, sum);

}

