// Program to print fibonacci series using recursion, array, and any loop.

#include <stdio.h>

// Function to calculate the nth Fibonacci number using recursion
int fibonacci(int n) {
    if(n <= 1)
        return n;
    else
        return fibonacci(n-1) + fibonacci(n-2);
}

int main() {
    int num, i;

    printf("Note: Please enter small number(BELOW 30) because this program uses recursion to calculate the Fibonacci series, which can be inefficient for large numbers of terms due to repeated calculations.\n\n");

    printf("Enter the number of terms: ");
    scanf("%d", &num);

    // Array to store the Fibonacci series
    int fib[num];

    // Calculate the Fibonacci series
    for(i = 0; i < num; i++) {
        fib[i] = fibonacci(i);
    }

    // Print the Fibonacci series
    printf("Fibonacci series: ");
    for(i = 0; i < num; i++) {
        printf("%d ", fib[i]);
    }
    printf("\n");

}

