// Program to demonstrates dynamic memory allocation using malloc and free functions.

#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;

    // Taking user input for the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &n);

    // Allocating memory for an integer array of size n
    int *dynamicArray = (int *)malloc(n * sizeof(int));

    // Checking if memory allocation is successful
    if (dynamicArray == NULL) {
        printf("Memory allocation failed. Exiting the program.\n");
        return 1;  // Return a non-zero value to indicate an error
    }

    // Filling the dynamic array with values
    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &dynamicArray[i]);
    }

    // Printing the elements of the dynamic array
    printf("Elements of the dynamic array:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", dynamicArray[i]);
    }
    printf("\n");

    // Deallocating the dynamically allocated memory
    free(dynamicArray);

    return 0;
}

