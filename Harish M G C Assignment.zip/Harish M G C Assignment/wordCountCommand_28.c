// Program to imitate the 'wc command' of linux terminal.

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *file;  // File pointer
    char ch;  // Character to read from file
    int lines = 0, words = 0, characters = 0, space = 0;  // Counters

    // Loop over each command line argument
    for(int i = 1; i < argc; i++) {
        // Open the file
        file = fopen(argv[i], "r");
        // If the file cannot be opened, print an error message and exit
        if(file == NULL) {
            printf("Cannot open file.\n");
            exit(0);
        }

        // Read each character from the file
        while((ch = fgetc(file)) != EOF) {
            characters++;  // Increment character count
            // If the character is a newline, increment line count
            if(ch == '\n' || ch == '\0') {
                lines++;
            }
            // If the character is a space, tab, newline, or null, increment word count
            if(ch == ' ' || ch == '\t' || ch == '\n' || ch == '\0') {
                words++;
                space = 0;
            } else if(space == 0) {
                space = 1;
            }
        }

        // Close the file
        fclose(file);

        // Print the counts
        printf("\nFile: %s\n", argv[i]);
        printf("Lines: %d\n", lines);
        printf("Words: %d\n", words);
        printf("Characters: %d\n", characters);
    }

    return 0;
}

