// Program to print factorial using for and while loops and rescursion:

#include <stdio.h>

// Function to calculate the factorial of a number using recursion
long long factorialRecursion(int n) {
    if(n == 0)
        return 1;
    else
        return n * factorialRecursion(n-1);
}

// Function to calculate the factorial of a number using a for loop
long long factorialForLoop(int n) {
    long long factorial = 1;
    for(int i = 1; i <= n; i++) {
        factorial *= i;
    }
    return factorial;
}

// Function to calculate the factorial of a number using a while loop
long long factorialWhileLoop(int n) {
    long long factorial = 1;
    int i = 1;
    while(i <= n) {
        factorial *= i;
        i++;
    }
    return factorial;
}

int main() {
    int num;

    printf("\nNote: Please note that the factorial of a number can be very large, so long data type is used to store the factorial. If the number is too large, the factorial may not fit in a long data type also. so, enter a small number\n\n");

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Factorial (recursion): %lld\n", factorialRecursion(num));
    printf("Factorial (for loop): %lld\n", factorialForLoop(num));
    printf("Factorial (while loop): %lld\n", factorialWhileLoop(num));

}

