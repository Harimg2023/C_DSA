// Program to check whether a given number is palindrome or not. if yes then print "Palindrome", if no, Reverse the number and add to the previos num and check whether now it is palindrome or not. if no then continue this process untill we get a palindrome.
// for example:
// scenario - 1:
// Enter a number: 174
//	reverse it : 471
//	Add them   : 645
//	reverse it : 546
//	Add them   : 1191     
//	reverse it : 1911    
//	Add them   : 3102
//	reverse it : 2013
//	Add them   : 5115   --->   Palindrome
//
// scenario - 2:	   
//	Enter a number: 121
//	                   ---> Palindrome

#include <stdio.h>

// Function to reverse a number
int reverse(int n) {
    int rev = 0;
    while(n != 0) {
        rev = rev * 10 + n % 10;
        n /= 10;
    }
    return rev;
}

// Function to check if a number is a palindrome
int isPalindrome(int n) {
    return (n == reverse(n));
}

int main() {
    int num;

    // Take the number as input from the user
    printf("Enter a number: ");
    scanf("%d", &num);

    while(1) {
        if(isPalindrome(num)) {
            printf("                 ---> Palindrome\n");
            break;
        } else {
            printf("reverse it : %d\n", reverse(num));
            num = num + reverse(num);
            printf("Add them   : %d\n", num);
        }
    }

}

