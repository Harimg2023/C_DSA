// Program to print magic matrix.

#include <stdio.h>
#define MAX_SIZE 100

int main() {
	int magicSquare[MAX_SIZE][MAX_SIZE];
	int n, i, j, num;

	// Taking the order of the magic square as input from the user
	printf("Enter the order of the magic square: ");
	scanf("%d", &n);

	// Initializing the magic square
	for(i = 0; i < n; i++) {
		for(j = 0; j < n; j++) {
			magicSquare[i][j] = 0;
		}
	}

	// Generating the magic square
	i = n / 2;
	j = n - 1;
	for(num = 1; num <= n * n;) {
		if(i == -1 && j == n) {
			i = 0;
			j = n - 2;
		} else {
			if(j == n) {
				j = 0;
			}
			if(i < 0) {
				i = n - 1;
			}
		}
		if(magicSquare[i][j]) {
			i++;
			j -= 2;
			continue;
		} else {
			magicSquare[i][j] = num++;
		}
		i--;
		j++;
	}

	// Printing the magic square
	printf("Magic Square of order %d:\n", n);
	for(i = 0; i < n; i++) {
		for(j = 0; j < n; j++) {
			printf("%4d", magicSquare[i][j]);
		}
		printf("\n");
	}

}

